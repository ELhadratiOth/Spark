--- u should be  connected as admin to  run this commands 
-- use this  to  connect as admin :
-- sudo -i -u postgres
-- psql



CREATE USER othman WITH PASSWORD 'othman';
CREATE DATABASE telecom_db OWNER othman;
GRANT ALL PRIVILEGES ON DATABASE telecom_db TO othman;
\c telecom_db
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO othman;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO othman;
GRANT ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA public TO othman;


-- to connect to that  db  using the  new user :
-- psql -U othman -d telecom_db -h localhost


-- first table  : 
CREATE TABLE normalized_records (
    record_id VARCHAR(36) PRIMARY KEY,
    record_type VARCHAR(50),
    timestamp VARCHAR(50),
    msisdn VARCHAR(50),
    secondary_msisdn VARCHAR(50),
    duration_sec FLOAT,
    data_volume_mb FLOAT,
    cell_id VARCHAR(50),
    technology VARCHAR(10),
    status VARCHAR(20)
);
