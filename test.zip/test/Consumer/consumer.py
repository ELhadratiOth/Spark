import yaml
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, when, lit,  from_json, to_json, struct
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, FloatType

def load_config(yaml_file="config.yaml"):
    with open(yaml_file, 'r') as file:
        config = yaml.safe_load(file)
    return config

# input schema 
input_schema = StructType([
    StructField("record_id", StringType(), nullable=False),
    StructField("record_type", StringType(), True),
    StructField("timestamp", StringType(), True),
    StructField("caller_id", StringType(), True),
    StructField("callee_id", StringType(), True),
    StructField("sender_id", StringType(), True),
    StructField("receiver_id", StringType(), True),
    StructField("user_id", StringType(), True),
    StructField("duration_sec", IntegerType(), True),
    StructField("data_volume_mb", FloatType(), True),
    StructField("session_duration_sec", IntegerType(), True),
    StructField("cell_id", StringType(), True),
    StructField("technology", StringType(), True)
])

# unified output schema
output_schema = StructType([
    StructField("record_id", StringType(), False),
    StructField("record_type", StringType(), True),
    StructField("timestamp", StringType(), True),
    StructField("msisdn", StringType(), True),
    StructField("secondary_msisdn", StringType(), True),
    StructField("duration_sec", FloatType(), True),
    StructField("data_volume_mb", FloatType(), True),
    StructField("cell_id", StringType(), True),
    StructField("technology", StringType(), True),
    StructField("status", StringType(), True) # alyaws it  gonna be  True  bcs in the  case of  error  it  should be  dropped 
])

def main():
    # Load configuration
    config = load_config()

    # Initialize Spark session
    spark = SparkSession.builder \
        .appName(config['mediation']['spark']['app_name']) \
        .master(config['mediation']['spark']['master']) \
        .config("spark.jars.packages", "org.postgresql:postgresql:42.6.0") \
        .getOrCreate()

    # Read streaming data from Kafka
    kafka_df = spark.readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", config['mediation']['input_kafka']['bootstrap_servers']) \
        .option("subscribe", config['mediation']['input_kafka']['topic']) \
        .option("startingOffsets", "earliest") \
        .load()

    # Parse JSON from Kafka value
    json_df = kafka_df.select(
        from_json(col("value").cast("string"), input_schema).alias("data")
    ).select("data.*")

    # Normalize records
    normalized_df = json_df.select(
        col("record_id"),
        col("record_type"),
        col("timestamp"),
        # Map msisdn: caller_id, sender_id, or user_id
        when(col("caller_id").isNotNull(), col("caller_id"))
        .when(col("sender_id").isNotNull(), col("sender_id"))
        .when(col("user_id").isNotNull(), col("user_id"))
        .otherwise(lit(None)).alias("msisdn"),
        # Map secondary_msisdn: callee_id or receiver_id
        when(col("callee_id").isNotNull(), col("callee_id"))
        .when(col("receiver_id").isNotNull(), col("receiver_id"))
        .otherwise(lit(None)).alias("secondary_msisdn"),
        # Duration: use session_duration_sec for data, duration_sec for voice
        when(col("record_type") == "data", col("session_duration_sec"))
        .when(col("record_type") == "voice", col("duration_sec"))
        .otherwise(lit(None)).cast("float").alias("duration_sec"),
        col("data_volume_mb"),
        col("cell_id"),  # No uppercasing, already uppercase
        col("technology"),
        # Initial status
        lit("valid").alias("status")
    )

    # Validate records
    validated_df = normalized_df.withColumn(
        "status",
        when(
            # Invalid msisdn: not +212 followed by 9 digits
            ~col("msisdn").rlike(r"^\+212[0-9]{9}$") |
            # Test numbers starting with 999
            col("msisdn").startswith("999") |
            # Negative duration or data volume
            (col("duration_sec").isNotNull() & (col("duration_sec") < 0)) |
            (col("data_volume_mb").isNotNull() & (col("data_volume_mb") < 0)) |
            # Unrecognized record_type
            ~col("record_type").isin("voice", "sms", "data"),
            "error"
        ).otherwise(col("status"))
    )

    # Filter valid records (drop errored records)
    valid_df = validated_df.filter(col("status") == "valid")

    # Deduplicate records (using watermark to handle late data)
    deduped_df = valid_df \
        .withWatermark("timestamp", "10 minutes") \
        .dropDuplicates(["record_id"])

    # Write valid records to Kafka
    valid_kafka_df = deduped_df.select(
        to_json(struct("*")).alias("value")
    )
    valid_kafka_query = valid_kafka_df.writeStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", config['mediation']['output_kafka']['bootstrap_servers']) \
        .option("topic", config['mediation']['output_kafka']['valid_topic']) \
        .option("checkpointLocation", "output/checkpoints/valid_kafka") \
        .start()

    # Write valid records to PostgreSQL
    def write_to_postgres(batch_df, batch_id):
        batch_df.write \
            .format("jdbc") \
            .option("url", config['mediation']['postgres']['url']) \
            .option("dbtable", config['mediation']['postgres']['table']) \
            .option("user", config['mediation']['postgres']['user']) \
            .option("password", config['mediation']['postgres']['password']) \
            .option("driver", config['mediation']['postgres']['driver']) \
            .mode("append") \
            .save()

    postgres_query = deduped_df.writeStream \
        .foreachBatch(write_to_postgres) \
        .option("checkpointLocation", "output/checkpoints/postgres") \
        .trigger(processingTime="10 seconds") \
        .start()

    spark.streams.awaitAnyTermination()

if __name__ == "__main__":
    main()
