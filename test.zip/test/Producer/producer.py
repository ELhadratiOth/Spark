import json
import random
import time
from datetime import datetime, timedelta ,timezone
import pandas as pd
from kafka import KafkaProducer
import uuid
import yaml
import string
import os

# load the config
def load_config(yaml_file="config.yaml"):
    with open(yaml_file, 'r') as file:
        config = yaml.safe_load(file)
    return config

# generate a phone number (normal or corrupted)
def generate_phone_number(error_mode=False):
    if not error_mode:
        # Normal: +212 followed by 9 digits
        digits = ''.join(random.choices(string.digits, k=9))
        return f"+212{digits}"
    else:
        return "999" + ''.join(random.choices(string.digits, k=9))

# kafka producer 
def kafka_producer(config):
    return KafkaProducer(
        bootstrap_servers=config['output']['kafka']['bootstrap_servers'],
        value_serializer=lambda v: json.dumps(v).encode('utf-8'),
        key_serializer=lambda k: k.encode('utf-8')
    )

# generate a single record
def generate_record(record_type, timestamp, error_mode=False, config=None):
    record = {"record_id": str(uuid.uuid4())}
    tech = random.choice(config['data_generation']['technologies'])
    cell_id = random.choice(config['data_generation']['cell_ids'])
    
    if record_type == "voice":
        record.update({
            "record_type": "voice",
            "timestamp": timestamp.isoformat(),
            "caller_id": generate_phone_number(error_mode and random.choice(["corrupted_data", "other"]) == "corrupted_data"),
            "callee_id": generate_phone_number(error_mode and random.choice(["corrupted_data", "other"]) == "corrupted_data"),
            "duration_sec": random.randint(10, 600),  
            "cell_id": cell_id,
            "technology": tech 
        })
    elif record_type == "sms":
        record.update({
            "record_type": "sms",
            "timestamp": timestamp.isoformat(),
            "sender_id": generate_phone_number(error_mode and random.choice(["corrupted_data", "other"]) == "corrupted_data"),
            "receiver_id": generate_phone_number(error_mode and random.choice(["corrupted_data", "other"]) == "corrupted_data"),
            "cell_id": cell_id,
            "technology": tech
        })
    elif record_type == "data":
        data_volume = random.uniform(0.1, 10) if tech == "2G" else random.uniform(1, 1000)  # 2G has lower data
        record.update({
            "record_type": "data",
            "timestamp": timestamp.isoformat(),
            "user_id": generate_phone_number(error_mode and random.choice(["corrupted_data", "other"]) == "corrupted_data"),
            "data_volume_mb": round(data_volume, 2),
            "session_duration_sec": random.randint(30, 3600),  
            "cell_id": cell_id,
            "technology": tech
        })

    if error_mode:
        error_type = random.choice(["missing_field", "unrecognized_service", "negative_value"])
        if error_type == "missing_field":
            if record_type == "voice":
                del record["callee_id"]
            elif record_type == "sms":
                del record["receiver_id"]
            elif record_type == "data":
                del record["data_volume_mb"]
        elif error_type == "unrecognized_service":
            record["record_type"] = "unknown"
        elif error_type == "negative_value":
            if record_type == "voice":
                record["duration_sec"] = -record["duration_sec"]
            elif record_type == "data":
                record["data_volume_mb"] = -record["data_volume_mb"]

    return record

# generate a batch of records
def generate_batch(num_records, start_time, config):
    records = []
    for _ in range(num_records):
        timestamp = start_time + timedelta(seconds=random.randint(0, 3600))
        record_type = random.choices(
            list(config['data_generation']['service_distribution'].keys()),
            weights=list(config['data_generation']['service_distribution'].values()),
            k=1
        )[0]
        error_mode = random.random() < config['data_generation']['error_ratio']
        record = generate_record(record_type, timestamp, error_mode, config)
        records.append(record)
    return records

def save_to_file(records, config):
    output_dir = config['output']['batch_output_path']
    os.makedirs(output_dir, exist_ok=True)
    
    if config['output']['format'] == "csv":
        file_path = os.path.join(output_dir, "telecom_records.csv")
        df = pd.DataFrame(records)
        mode = 'a' if os.path.exists(file_path) else 'w'
        df.to_csv(file_path, mode=mode, index=False, header=not os.path.exists(file_path))
    elif config['output']['format'] == "jsonl":
        file_path = os.path.join(output_dir, "telecom_records.jsonl")
        with open(file_path, "a") as f:
            for record in records:
                json.dump(record, f)
                f.write("\n")

def stream_to_kafka(records, producer, config):
    for record in records:
        try:
            producer.send(
                topic=config['output']['kafka']['topic'],
                key=record["record_id"],
                value=record
            )
            producer.flush()
        except Exception as e:
            print(f"Failed to send record {record['record_id']}: {e}")
        time.sleep(10)    
    print(f"Streamed {len(records)} records to Kafka topic {config['output']['kafka']['topic']}")

def main():
    config = load_config()
    
    start_time =datetime.now(timezone.utc)
    records = generate_batch(config['data_generation']['records_per_hour'], start_time, config)
    
    if config['output']['format'] in ["csv", "jsonl"]:
        save_to_file(records, config)
        print(f"Appended {len(records)} records to {config['output']['format']} file in {config['output']['batch_output_path']}")
    elif config['output']['format'] == "kafka":
        producer = kafka_producer(config)
        stream_to_kafka(records, producer, config)
        producer.flush()

if __name__ == "__main__":
    main()
